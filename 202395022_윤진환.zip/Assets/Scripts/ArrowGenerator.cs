using UnityEngine;

public class ArrowGenerator : TimedSpawner
{
    [SerializeField] private GameObject arrowPrefab;

    protected override GameObject Prefab => arrowPrefab;
}