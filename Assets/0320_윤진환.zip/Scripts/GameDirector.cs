using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class GameDirector : MonoBehaviour
{
    [SerializeField] private Image hpGauge;
    [SerializeField] private TextMeshProUGUI hpText;
    [SerializeField] private TextMeshProUGUI gameOverText;
    [SerializeField] private Button start;

    bool isGameOver = false;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        if(this.hpGauge == null) Debug.LogError("hpGauge is not assigned in the inspector.");
        if(this.hpText == null) Debug.LogError("hpText is not assigned in the inspector.");
        if(this.gameOverText == null) Debug.LogError("gameOverText is not assigned in the inspector.");
        if(this.start == null) Debug.LogError("start Button is not assigned in the inspector.");

        if(GameStateManager.Instance.CurrentState == GameState.IsPlaying)
        {
            if (this.gameOverText != null) this.gameOverText.gameObject.SetActive(false);
            if (this.start != null) this.start.gameObject.SetActive(false);
        }
    }

    public void DecreaseHp()
    {
        if (isGameOver) return;

        this.hpGauge.fillAmount = Mathf.Clamp01(this.hpGauge.fillAmount - 0.1f);
        if (this.hpGauge.fillAmount <= 0 && !isGameOver)
        {
            GameStateManager.Instance.SetGameState(GameState.GameOver);
            OnGameOver();
        }
    }

    void OnGameOver()
    {
        if (isGameOver) return;
        isGameOver = true;

        // UI ǥ��
        if (this.gameOverText != null) this.gameOverText.gameObject.SetActive(true);
        if (this.start != null) this.start.gameObject.SetActive(true);

        // ������ ��Ȱ��ȭ (�±� 'system' ���)
        GameObject systemObj = null;
        try { systemObj = GameObject.FindWithTag("system"); } catch { systemObj = null; }
        if (systemObj != null)
        {
            ArrowGenerator gen = systemObj.GetComponent<ArrowGenerator>();
            if (gen != null) gen.enabled = false;
        }

        // ��� ȭ�� ��Ȱ��ȭ (�±� 'arrow' ���)
        GameObject[] arrowObjs = GameObject.FindGameObjectsWithTag("arrow");
        foreach (var go in arrowObjs)
        {
            if (go == null) continue;
            ArrowController ac = go.GetComponent<ArrowController>();
            if (ac != null) ac.enabled = false;
        }

        // �÷��̾� �Է�/�̵� ���� (�±� 'Player' ���)
        GameObject playerObj = null;
        try { playerObj = GameObject.FindWithTag("Player"); } catch { playerObj = null; }
        if (playerObj != null)
        {
            PlayerController pc = playerObj.GetComponent<PlayerController>();
            if (pc != null) pc.enabled = false;
        }

        // ���� ����
        Time.timeScale = 0f;

        Debug.Log("Game Over (tag-based)");
    }

    public void RestartGame()
    {
        // �ð� ������ ����
        Time.timeScale = 1f;

        // HP �ʱ�ȭ
        if (this.hpGauge != null) this.hpGauge.fillAmount = 1f;

        // UI �ʱ�ȭ
        if (this.gameOverText != null) this.gameOverText.gameObject.SetActive(false);
        if (this.start != null) this.start.gameObject.SetActive(false);

        // ��� ȭ�� ���� (�±� 'arrow' ���)
        GameObject[] arrowObjs = GameObject.FindGameObjectsWithTag("arrow");
        foreach (var go in arrowObjs)
        {
            if (go != null) Destroy(go);
        }

        // ������ ��Ȱ��ȭ
        GameObject systemObj = null;
        try { systemObj = GameObject.FindWithTag("system"); } catch { systemObj = null; }
        if (systemObj != null)
        {
            ArrowGenerator gen = systemObj.GetComponent<ArrowGenerator>();
            if (gen != null) gen.enabled = true;
        }

        // �÷��̾� ��Ȱ��ȭ
        GameObject playerObj = null;
        try { playerObj = GameObject.FindWithTag("Player"); } catch { playerObj = null; }
        if (playerObj != null)
        {
            PlayerController pc = playerObj.GetComponent<PlayerController>();
            if (pc != null) pc.enabled = true;

            // �÷��̾� ��ġ �ʱ�ȭ ���� (����)
            playerObj.transform.position = new Vector3(0, playerObj.transform.position.y, playerObj.transform.position.z);
        }

        isGameOver = false;

        GameStateManager.Instance.SetGameState(GameState.IsPlaying);
    }

    // Update is called once per frame
    void Update()
    {
        if(GameStateManager.Instance.CurrentState == GameState.IsPlaying)
        {
            if (this.hpText != null && this.hpGauge != null)
                this.hpText.text = Mathf.RoundToInt(this.hpGauge.fillAmount * 100) + "%";
        }
    }
}
